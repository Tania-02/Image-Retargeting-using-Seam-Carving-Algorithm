
%% The code is used for extract the slaiency map for images. Please cite the following paper when using the code.
% Yuming Fang, Zhenzhong Chen, Weisi Lin, Chia-Wen Lin, 'Saliency Detection in the Compressed Domain for Adaptive Image Retargeting', Transactions on Image Processing (T-IP), 21(9): 3888-3901, 2012.
% or Yuming Fang, Zhenzhong Chen, Weisi Lin, Chia-Wen Lin, 'Saliency-based Image Retargeting in the Compressed Domain', ACM International Conference on Multimedia 2011 (ACM MM11). 

%% if the input image is large, please resize the image into a smaller one (such as 300*300) for the time cost. 


clear all
clc

input_img = 'img9.jpg';
img = imread(input_img);
smap = DCT_Smap(img);
imshow(smap);